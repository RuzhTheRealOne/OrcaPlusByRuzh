OrcaPlusByRuzh - README

────────────────────────────────────

📜 Descripción:
Este es un fork personalizado de Orca Hub, mejorado por Ruzh (TRuzh_). 
Incluye funciones adicionales especialmente diseñadas para juegos como Be NPC or DIE.

────────────────────────────────────

🚀 Características incluidas:

- Watermark animado "TRuzh_" (estilo gradiente arcoíris).
- ESP para jugadores (ignorando NPCs).
- Auto completar tareas (Auto Task) en Be NPC or DIE.
- Sistema de Stamina infinita.
- Overlay de estados activos (ESP y AutoTask ON/OFF).
- Botón "Kill All Changes" para limpiar todo.
- Tab de "Juegos Compatibles" al estilo Orca Hub (estético y modular).
- Animaciones suaves, compatibilidad total, modularidad para añadir más juegos.

────────────────────────────────────

🛠️ Instrucciones:

- latest2.lua contiene todo el script modificado.
- latest2.lua debe cargarse desde tu repositorio junto al latest.lua original.
- El Tab de Juegos y funciones especiales están integrados automáticamente.
- Puedes añadir más juegos editando fácilmente la función createGameCard().

────────────────────────────────────

🧠 Autor: 
TRuzh_ (RuzhTheRealOne)

────────────────────────────────────

🌟 Gracias por usar OrcaPlusByRuzh.

